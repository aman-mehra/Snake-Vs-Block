package GameObjects;

public class Wall
{
}
