package GameObjects;

public interface Token
{

}
